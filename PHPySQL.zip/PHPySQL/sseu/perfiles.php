<!DOCTYPE html>
<html lang="en">
   <head>
     <title>SSE UNISTMO</title>
     <meta charset="utf-8">
     <meta name = "format-detection" content = "telephone=no" />
     <link rel="icon" href="images/icono.png" >
     <link rel="shortcut icon" href="images/icono.png"  />
     <link  rel="stylesheet" media="screen" href="css/style.css">
     <link  rel="stylesheet" href="css/font-awesome.css">
     <link  rel="stylesheet" href="css/carousel.css">

     <script src="js/jquery.js"></script>
     <script src="js/jquery-migrate-1.1.1.js"></script>
     <script src="js/script.js"></script> 
     <script src="js/jquery.equalheights.js"></script>
     <script src="js/superfish.js"></script>
     <script  src="js/jquery.responsivemenu.js"></script>
     <script  src="js/jquery.mobilemenu.js"></script>
     <script  src="js/jquery.easing.1.3.js"></script>

     <script src="js/jquery.carouFredSel-6.1.0-packed.js"></script>
     <script  src="js/jquery.touchSwipe.min.js"></script>

     <script>
          
          $(window).load (
            function(){$('.carousel1').carouFredSel({auto: false, prev: '.prev1',next: '.next1', width: 940, items: {
                visible : {min: 1, max: 1},
                height: 'auto',
                width: 940,
            }, responsive: true, scroll: 1, mousewheel: false, swipe: {onMouse: true, onTouch: true}});
          }); 
    </script>
  </head>
  <body oncontextmenu="return false" onkeydown="return false">
    <!--==============================header=================================-->
    <header>
      <div class="container_12">
        <div class="grid_12">
          <h1><a href="index.html"><img src="images/logo4.png" alt="Prospect best opportunity to succeed"></a> </h1>
          <div class="menu_block">
            <nav>
              <ul class="sf-menu">
               <li><a href="index.html">Inicio</a></li>
               <li  class="current"><a href="#">Perfil de egresado</a></li>
               <li><a href="bolsa_tra.php">Bolsa de trabajo</a></li>
               <li><a href="informacion.html">Información</a></li>
               <li><a href="#">Acerca de</a> </li>
               <li><a href="login.html">Login</a> </li>
               <li><a href="registro.html">Registro</a> </li>
              </ul>
            </nav>
            <div class="clear"></div>
          </div>
        </div>
      </div>
    </header>

    <!--=======content================================-->
    <div class="content projects">
      <div class="container_12">
        <div class="grid_12">
          <h3>Perfiles</h3>
          <div class="carousel_wrapper">
            <a href="#" class="prev1"></a><a href="#" class="next1"></a>
            <div>
              <ul class="carousel1">
                <li>
                  <div class="grid_11">
                    <div class="box ic5"><div class="maxheight">
                      <h3>Joel<br>
                      Martinez Oviedo</h3><img src="images/professor.png" style="width: 48px; height: 48px;"><!--i class=" icon-group"></i-->
                      <p>Masagni dolores eoquie voluptate msequi nesciunt. Nique porro quisquam est qui dolorem ipsumquia dolor sitamet consectet, adipisci unumquam eius.</p>
                      <a href="#" class="btn">Ver</a></div>
                    </div>
                  </div>
                </li>

                <li>
                  <div class="grid_11">
                    <div class="box ic6"><div class="maxheight">
                      <h3>Daniel<br>
                      Canton</h3><img src="images/professor.png" style="width: 48px; height: 48px;"><!--i class=" icon-group"></i-->
                      <p>Adipisci velitsed quia non numqueius modi tempora inciduntut labore et doloreas magnam aliquam quaerat voluptatem. ut enim adima veniam, quis nostrum.</p>
                      <a href="#" class="btn">Ver</a></div>
                    </div>
                  </div>
                </li>

                <li>
                  <div class="grid_11">
                    <div class="box ic7"><div class="maxheight">
                      <h3>Oswaldo<br>
                      Apellidos</h3><img src="images/professor.png" style="width: 48px; height: 48px;"><!--i class=" icon-group"></i-->
                      <p>Jerta baditaut onsequser untur magni dolores eoquie voluptate msequi nesciunt. Nique porro quisquam est qui dolorem ipsumquia dolor sitamet consectet.</p>
                      <a href="#" class="btn">Ver</a></div>
                    </div>
                  </div>
                </li>

                <li>
                  <div class="grid_11">
                    <div class="box ic8"><div class="maxheight">
                      <h3>Nombre <br>
                      Apellidos</h3><img src="images/professor.png" style="width: 48px; height: 48px;"><!--i class=" icon-group"></i-->
                      <p>Folern aditaut onsequ untur magni dolores eoquie voluptate msequi nesciunt. Nique porro quisquam est qui dolorem ipsumquia dolor sitamet consectet.</p>
                      <a href="#" class="btn">Ver</a></div>
                    </div>
                  </div>
                </li>

                <li>
                  <div class="grid_11">
                    <div class="box ic9"><div class="maxheight">
                      <h3>Nombre<br>
                      Apellidos</h3><img src="images/professor.png" style="width: 48px; height: 48px;"><!--i class=" icon-group"></i-->
                      <p>Adipisci velitsed quia non numqueius modi tempora inciduntut labore et doloreas magnam aliquam quaerat voluptatem. ut enim adima veniam, quis nostrum.</p>
                      <a href="#" class="btn">Ver</a></div>
                    </div>
                  </div>
                </li>

                <li>
                  <div class="grid_11">
                    <div class="box ic2"><div class="maxheight">
                      <h3>Nombre<br>
                      Apellidos</h3><img src="images/professor.png" style="width: 48px; height: 48px;"><!--i class=" icon-group"></i-->
                      <p>Adipisci velitsed quia non numqueius modi tempora inciduntut labore et doloreas magnam aliquam quaerat voluptatem. ut enim adima veniam, quis nostrum.</p>
                      <a href="#" class="btn">Ver</a></div>
                    </div>
                  </div>
                </li>

                <li>
                  <div class="grid_11">
                    <div class="box ic3"><div class="maxheight">
                      <h3>Nombre<br> 
                      Apellidos</h3><img src="images/professor.png" style="width: 48px; height: 48px;"><!--i class=" icon-group"></i-->
                      <p>Jerta baditaut onsequser untur magni dolores eoquie voluptate msequi nesciunt. Nique porro quisquam est qui dolorem ipsumquia dolor sitamet consectet.</p>
                      <a href="#" class="btn">Ver</a></div>
                    </div>
                  </div>
                </li>

                <li>
                  <div class="grid_11">
                    <div class="box ic4"><div class="maxheight">
                      <h3>Nombre<br>
                      Apel</h3><img src="images/professor.png" style="width: 48px; height: 48px;"><!--i class=" icon-group"></i-->
                      <p>Folern aditaut onsequ untur magni dolores eoquie voluptate msequi nesciunt. Nique porro quisquam est qui dolorem ipsumquia dolor sitamet consectet.</p>
                      <a href="#" class="btn">Ver</a></div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div> <!-- termina carusel -->
          <!--div class="clear cl2"></div-->
        </div>
      </div>
    </div>

    <!--==============================footer=================================-->
    <div class="container_12">
      <div class="grid_12">
        <footer>
          <div class="container_12">
              <div class="grid_4">
                <div class="widget">
                  <h4>Visítanos</h4>
                  <address>
                  <strong>UNISTMO</strong><br>
                   Ciudad Universitaria S/N, Barrio Santa Cruz, 4a. Sección<br>
                   Sto. Domingo Tehuantepec, Oax., México C.P. 70760</address>
                  <p>
                    <i class="icon-phone"></i>Teléfono: (971) 522 4050 extensiones 111 y 123.<br>
                  </p>
                </div>
              </div>

              <div class="grid_4">
                <div class="widget">
                  <h4>Explora</h4>
                  <ul class="link-list">
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="perfiles.php">Perfiles</a></li>
                    <li><a href="bolsa_tra.php">Bolsa de trabajo</a></li>
                    <li><a href="informacion.html">Información</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="login.html">Login</a></li>
                    <li><a href="registro.html">Registro</a></li>
                  </ul><br>
                </div>
              </div>

              <div class="grid_4">
                <div class="widget">
                  <h4>Sitios de interés</h4>
                  <ul class="link-list">
                    <li><a href="http://www.unistmo.edu.mx/" target="_blank">Universidad Del Istmo</a></li>
                    <li><a href="http://www.unistmo.edu.mx/~servesc/web/" target="_blank">Servicios Escolares</a></li>
                    <li><a href="http://www.unistmo.edu.mx/bibliotecas/index.html" target="_blank">Biblioteca</a></li>
                  </ul><br>
                </div>
              </div>
          </div> <!-- termina la clase container -->

          <div class="socials">
            <a href="https://www.facebook.com/profile.php?id=100006655577072">facebook</a> | 
            <a href="https://www.youtube.com/channel/UCgm8jP25b45r_PNcAgWca6g">youtube</a> | 
            <a href="#">google+</a>
          </div>

          <div class="copy">
            Carlos Ricardo  CJ 2018 | Darck Design
          </div>
        </footer>
      </div>
    </div>
  </body>
</html>