<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8"/>
        <title>.: Registro de egresado :.</title>
        <link rel="stylesheet" href="css/estilos_formularios.min.css">
        <link href='http://fonts.googleapis.com/css?family=Overlock' rel='stylesheet' type='text/css'><!-- font-family: 'Open --> 
        <link href='http://fonts.googleapis.com/css?family=Open Sans' rel='stylesheet' type='text/css'><!-- font-family: 'Open --> 
        <link  rel="stylesheet" href="css/estilo_ventanas_modal.min.css">

        <script src="js/jquery-3.1.1.min.js"></script>    
        <script src="js/main.js"></script>
    </head>
    <body oncontextmenu="return false">
	   <!--strong><h2>Crea tu Cuenta</h2></strong-->
    	<div class="contenedor-form">
            <div class="toggle">
                <span>Iniciar Sesión</span>
            </div>
            
            <div class="formulario">
                <h2>Crea tu Cuenta</h2>
                <form action="#">
                    <input type="text" placeholder="Usuario" required>
                    
                    <input type="password" placeholder="Contraseña" required>
                    
                    <input type="email" placeholder="Correo Electronico" required>
                    
                    <!--input type="text" placeholder="Teléfono" required-->
                    
                    <input type="submit" value="Registrarse">
                </form>
            </div>
            
            <div class="formulario">
                <h2>Iniciar Sesión</h2>
                <form action="#">
                    <input type="text" placeholder="Usuario" required>
                    <input type="password" placeholder="Contraseña" required>
                    <input type="submit" value="Iniciar Sesión">
                </form>
            </div>
        </div>
        
    </body>
</html>

