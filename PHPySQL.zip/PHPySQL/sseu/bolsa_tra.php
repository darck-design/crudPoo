<!DOCTYPE html>
<html lang="en">
  <head>
    <title>SSE UNISTMO</title>
    <meta charset="utf-8">
    <meta name = "format-detection" content = "telephone=no" />
    <link rel="icon" href="images/icono.png" >
    <link rel="shortcut icon" href="images/icono.png"  />
    <link  rel="stylesheet" media="screen" href="css/style.min.css">
    <link  rel="stylesheet" href="css/font-awesome.css">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/estilo_buscador.css">
    <script src="js/jquery.js"></script>
    <script src="js/jquery-migrate-1.1.1.js"></script>
    <script src="js/script.js"></script> 
    <script src="js/jquery.equalheights.js"></script>
    <script src="js/superfish.js"></script>
    <script  src="js/jquery.responsivemenu.js"></script>
    <script  src="js/jquery.mobilemenu.js"></script>
    <script  src="js/jquery.easing.1.3.js"></script>
  </head>
  <body oncontextmenu="return false" onkeydown="return false">
    <!--==============================header=================================-->
    <header>
      <div class="container_12">
        <div class="grid_12">
          <h1><a href="index.html"><img src="images/logo4.png" alt="Prospect best opportunity to succeed"></a> </h1>
          <div class="menu_block">
            <nav>
              <ul class="sf-menu">
               <li><a href="index.html">Inicio</a></li>
               <li><a href="perfiles.php">Perfil de egresado</a> </li>
               <li class="current"><a href="bolsa_tra.php">Bolsa de trabajo</a> </li>
               <li><a href="informacion.html">Información</a> </li>
               <li><a href="#">Acerca de</a> </li>
               <li><a href="login.html">Login</a> </li>
               <li><a href="registro.html">Registro</a> </li>
              </ul>
            </nav>
            <div class="clear"></div>
          </div>
        </div>
      </div>
    </header>

    <!--=======content================================-->
    <div class="content">
      <div class="container_12">
        <div class="grid_12 prv">
          <h3>Buscar ofertas</h3>
          
          <div class="grid_4">
            <div class="widget">
              <input type="search" id="search" placeholder="palabra clave" />
            </div>
          </div>

          <div class="grid_4">
            <div class="widget">
              <select class="container-4">
                <option value=" --- ">Seleccione</option>
                <option value="1" selected="selected">Marketing / Ventas</option>
                <option value="2">Administración / Oficina</option>
                <option value="3">Atención a clientes</option>
                <option value="4">Contabilidad / Finanzas</option>
                <option value="5">Hostelería / Turismo</option>
                <option value="6">Almacén / Logística</option>
                <option value="7">Informática / Telecomunicaciones</option>
                <option value="8">Producción / Operaciones</option>
                <option value="9">Ingeniería</option>
                <option value="10">Servicios Generales, Aseo y Seguridad</option>
                <option value="11">Mantenimiento y Reparaciones Técnicas</option>
                <option value="12">Recursos Humanos</option>
                <option value="13">Medicina / Salud</option>
                <option value="14">Docencia</option>
                <option value="15">Construcción y obra</option>
                <option value="16">CallCenter / Telemercadeo</option>
                <option value="17">Diseño / Artes gráficas</option>
                <option value="18">Mercadeo / Publicidad / Comunicación</option>
                <option value="19">Compras / Comercio Exterior</option>
                <option value="20">Investigación y Calidad</option>
                <option value="21">Legal / Asesoría</option>
                <option value="22">Dirección / Gerencia</option>
                <option value="23">Otro</option>
              </select>
            </div>
          </div>

          <div class="grid_1">
            <div class="widget2">
              <button class="icon"><img src="images/buscar.png" style="width: 16px; height: 16px;"></button> 
            </div>
          </div>

        </div>
      </div>
    </div>
    
    <div class="content">
      <div class="container_12">
        <div class="grid_12 res">
          <h3> Marketing / Ventas</h3>
          <div class="grid_5">
            <div class="widget">
              <p><strong>AGENTE DE VENTAS</strong><br />
              <small><em>VALORO</em></small></p> 
              <p>VALORO EMPRESA MEXICANA L&Iacute;DER, DEDICADA AL DISE&Ntilde;O, PRODUCCI&Oacute;N Y COMERCIALIZACI&Oacute;N&nbsp;&nbsp; DE JOYER&Iacute;A FINA CON MAS DE 30 A&Ntilde;OS EXPERIENCIA EN EL MERCADO C ...</p>
            </div>
          </div>

          <div class="grid_2">
            <div class="widget">
              <p class="text-center m-top25px"><img src="images/pin_location.png"/>
              <small>Zapopan, Jalisco</small></p> 
            </div>
          </div>

          <div class="grid_2">
            <div class="widget">
              <br />
              <p>$6000</p><br />   
              <p><small>Tipo de Contrato:<br />permanente</small></p>
            </div>
          </div>

          <div class="grid_2">
            <div class="widget">
              <br/><br/><a class="btn btn-info btn-sm m-top25px" href="#">Ver Más</a><br/><br/>
              <a class="btn btn-primary btn-sm m-top25px" href="#">Postular</a>
            </div>
          </div>
          <br>
          <div class="grid_2">
            <div class="widget">
              <br>
            </div>
          </div>

        </div>
        <hr/>

        <div class="grid_12 res">

          <div class="grid_5">
            <div class="widget">
              <p><strong>AGENTE DE VENTAS</strong><br />
              <small><em>VALORO</em></small></p> 
              <p>VALORO EMPRESA MEXICANA L&Iacute;DER, DEDICADA AL DISE&Ntilde;O, PRODUCCI&Oacute;N Y COMERCIALIZACI&Oacute;N&nbsp;&nbsp; DE JOYER&Iacute;A FINA CON MAS DE 30 A&Ntilde;OS EXPERIENCIA EN EL MERCADO C ...</p>
            </div>
          </div>

          <div class="grid_2">
            <div class="widget">
              <p class="text-center m-top25px"><img src="images/pin_location.png"/>
              <small>Zapopan, Jalisco</small></p> 
            </div>
          </div>

          <div class="grid_2">
            <div class="widget">
              <br />
              <p>$6000</p><br />   
              <p><small>Tipo de Contrato:<br />permanente</small></p>
            </div>
          </div>

          <div class="grid_2">
            <div class="widget">
              <br/><br/><a class="btn btn-info btn-sm m-top25px" href="#">Ver Más</a><br/><br/>
              <a class="btn btn-primary btn-sm m-top25px" href="#">Postular</a>
            </div>
          </div>
          <br>
          <div class="grid_2">
            <div class="widget">
              <br>
            </div>
          </div>

        </div>
        <hr/>

      </div>
    </div>
    <!--==============================footer=================================-->
    <div class="container_12">
      <div class="grid_12">
        <footer>
          <div class="container_12">
              <div class="grid_4">
                <div class="widget">
                  <h4>Visítanos</h4>
                  <address>
                  <strong>UNISTMO</strong><br>
                   Ciudad Universitaria S/N, Barrio Santa Cruz, 4a. Sección<br>
                   Sto. Domingo Tehuantepec, Oax., México C.P. 70760</address>
                  <p>
                    <i class="icon-phone"></i>Teléfono: (971) 522 4050 extensiones 111 y 123.<br>
                  </p>
                </div>
              </div>

              <div class="grid_4">
                <div class="widget">
                  <h4>Explora</h4>
                  <ul class="link-list">
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="perfiles.php">Perfiles</a></li>
                    <li><a href="bolsa_tra.php">Bolsa de trabajo</a></li>
                    <li><a href="informacion.html">Información</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="login.html">Login</a></li>
                    <li><a href="registro.html">Registro</a></li>
                  </ul><br>
                </div>
              </div>

              <div class="grid_4">
                <div class="widget">
                  <h4>Sitios de interés</h4>
                  <ul class="link-list">
                    <li><a href="http://www.unistmo.edu.mx/" target="_blank">Universidad Del Istmo</a></li>
                    <li><a href="http://www.unistmo.edu.mx/~servesc/web/" target="_blank">Servicios Escolares</a></li>
                    <li><a href="http://www.unistmo.edu.mx/bibliotecas/index.html" target="_blank">Biblioteca</a></li>
                  </ul>
                </div>
              </div>
          </div> <!-- termina la clase container -->

          <div class="socials">
            <a href="https://www.facebook.com/profile.php?id=100006655577072">facebook</a> | 
            <a href="https://www.youtube.com/channel/UCgm8jP25b45r_PNcAgWca6g">youtube</a> | 
            <a href="#">google+</a>
          </div>

          <div class="copy">
            Carlos Ricardo  CJ 2018 | Darck Design
          </div>
        </footer>
      </div>
    </div>  
  </body>
</html>