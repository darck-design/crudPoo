<?php  
	session_start();
	require 'funcs/conexion.php';
	require 'funcs/funcs.php';
	require 'funcs/consultas.php';

	if(!isset($_SESSION['logueado']) && !$_SESSION['logueado'] || !isset($_SESSION['admin_logueado']) && !$_SESSION['admin_logueado']){
    	header("location: logout.php");
  	}
	
	$titulo = limpiarCadena($mysqli->real_escape_string($_POST['titulot']));
	
	if(isset($titulo)&&$titulo!=""){
		global $mysqli;

		$query = "SELECT id FROM test WHERE test.titulo = '$titulo'";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$result = $stmt->get_result();
		$stmt->close();

		$row_a = $result->fetch_row(); 

		$consulta = "DELETE FROM respuestas WHERE id_test = $row_a[0]";
		$datos = $mysqli->query($consulta);

		if(!$datos || $mysqli->errno) die("error: no se pudo borrar las respuestas del test asignado ".$mysqli->errno);

		$consulta = "DELETE FROM preguntas WHERE id_test = $row_a[0]";
		$datos = $mysqli->query($consulta);

		if(!$datos || $mysqli->errno) die("error: no se pudo borrar las preguntas del test asignado ".$mysqli->errno);

		$consulta = "DELETE FROM tasignados WHERE id_test = $row_a[0]";
		$datos = $mysqli->query($consulta);

		if(!$datos || $mysqli->errno) die("error: no se pudo borrar el test asignado ".$mysqli->errno);

		$consulta = "DELETE FROM test WHERE titulo = '$titulo'";
		$datos = $mysqli->query($consulta);

		if(!$datos || $mysqli->errno) die("error: no se pudo borrar el test en la tabla test ".$mysqli->errno);
	}
	
	header("location: lista_test.php");
 ?> 