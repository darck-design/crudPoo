<?php
	session_start();
	$_SESSION['logueado'] = false;
	$_SESSION['admin_logueado'] = false;
	session_destroy();
	
	header("location: index.php");
	
?>