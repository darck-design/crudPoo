<?php
  session_start();
  include('funcs/conexion.php');
  require 'funcs/consultas.php';

  $tests=consultarTests();
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
    ?>
  </head>
  <body>
    <?php
      require_once 'menu.php';
      if(!isset($_SESSION['logueado']) && !isset($_SESSION['admin_logueado'])){
        imprimirMenu("inicio");
      }else if(isset($_SESSION['logueado']) && isset($_SESSION['admin_logueado']) && $_SESSION['admin_logueado']){
        imprimirMenu("ca");
      }else if(isset($_SESSION['logueado']) && $_SESSION['logueado'] && !isset($_SESSION['admin_logueado'])){
        imprimirMenu("cc");
      }
      
    ?>
      
    <div class="container" >
      <p>Esta pagina tiene el objetivo de proporcionar una ayuda para el estudio de algunos temas para subir de nivel...<br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto corporis blanditiis reiciendis. Ipsam possimus, corporis natus at nobis, saepe ex magni recusandae ullam, nesciunt aliquam excepturi impedit labore odio sint!<br>A contienuación se muestra la lista de test que puedes realizar en esta plataforma, para mas informacion contacte al número 9711486325</p>
      <h3>Lista de test creados</h3>
      <div id="tab">
        <table class="table table-hover" >
          <thead>
            <tr>
              <th>Titulo</th>
              <th>Numero de preguntas</th>
            </tr>
          </thead>

          <tbody>
            <?php foreach($tests as $test){ ?>
              <tr>
                <td><?php echo $test['titulo']; ?></td>
                <td><?php echo $test['totalp']; ?></td>
                <td>
                  <input type="text" name="titulot" class='hide' value="<?php echo $test['titulo']; ?>">
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </body>
</html>