<?php
  session_start();
  include('funcs/conexion.php');
  require 'funcs/consultas.php';
  require 'funcs/funcs.php';

  if(isset($_SESSION['logueado']) && $_SESSION['logueado'] && isset($_SESSION['admin_logueado']) && $_SESSION['admin_logueado']){
	  if(!empty($_POST)){
		  if(isset($_POST['testSel'])){ 
			  if(strcmp($_POST['testSel'],'Escoja')==0){
				$_SESSION['mnsjError']= "Por favor selecciona un titulo";
			  }else{ 
				   $idTest = $_POST['testSel'];
			  $_SESSION['valIdTest'] = $idTest;
			  $preguntas = getAllQuestions($idTest);
			  $_SESSION['botonTrue'] = true;
			   $_SESSION['tituloSave']=getATest($_SESSION['valIdTest']);
			  }
		  }elseif(isset($_POST['preguntasEditar'])){
			  
			  $_SESSION['tituloSave']=getATest($_SESSION['valIdTest']);
		
			  $valID = $_POST['preguntasEditar'];
			  $_SESSION['IdPregunts'] = $valID;
			  //ESTO ES PARA RECORDAR LA LISTA DE PREGUNTAS
			  $preguntas = getAllQuestions($_SESSION['valIdTest']);
			  $_SESSION['tamnResp'] = $preguntas->num_rows;
			  //ESTO ES PARA LA PREGUNTA A EDITAR
			  $preguntaEditar = getPregunta($valID);
			  //ESTO ES PARA RECUPERAR LAS RESPUESTAS
				$respuestasEditar = getRespuestasEditar($valID);
			  $_SESSION['editarTrue'] = true;
			  $_SESSION['botonTrue'] = true;
		  }elseif(isset($_POST['EditQ'])){
			  $cadena = $_POST['EditQ'];$band=0;
			  
			  $vlAns=setUpdateQ($cadena,$_SESSION['IdPregunts']);
			  if($vlAns){$band=1;}else{$band=0;}
			  $respuestasEditar = getRespuestasEditar($_SESSION['IdPregunts']);
			  while($row_pe = $respuestasEditar->fetch_row()){
				  if(isset($_POST[$row_pe[2]])){
					setUpdateA($_POST[$row_pe[2]],$_SESSION['IdPregunts'],$row_pe[2]);  
				  }
			  }
			  if($band==1){$_SESSION['mnsjError']= "Actualizaciones Satisfactorias";}
		  }else{
			  $valID = 0;
		  }
	  }
    $tests=consultarTests();
  }else{
      header("location: index.php");
  }
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
    ?>
  </head>
  <body>
	  
    <?php
      require_once 'menu.php';
      imprimirMenu("lt");
	  if(isset($_SESSION['mnsjError'])){
		  echo "<script type='text/javascript'>
           $(document).ready(function() {
    		$('#modalError').modal('show'); 
				});
        </script>";
	  }
    ?>
    <div class="container" >
      <h3>Editar preguntas</h3>
		<div class="row">
			  <div class="col-sm-8"> 
			<form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">  
			<?php if(isset($_SESSION['editarTrue'] )){
				$row_c = $preguntaEditar->fetch_row();
				echo "<div class='form-group'>
					<label for='questions'>Pregunta</label>
					<input type='text' class='form-control' id='preguntaE' value='$row_c[0]' name='EditQ' required autofocus autocomplete='off'></div>";
				echo "<br/>"; $j=1;
		while($row_d = $respuestasEditar->fetch_row()){
			echo " <div class='form-group'>";
			if($row_d[1]==1){echo "<label for='answer'>Respuesta Correcta</label>";	
			}else{echo "<label for='answer'>Respuesta</label>";}
			echo"<input type='text' class='form-control' id='answer' value='$row_d[0]' name='$row_d[2]' required autofocus autocomplete='off'></div>";
		$j=$j+1;
		}
				
		echo "<button type='submit' class='btn btn-primary'>Actualizar</button>";
			unset($_SESSION['editarTrue']);
		} ?>
			</form>
				  
				  
			</div>
			  <div class="col-sm-4">
				  
				<form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">  
				<div class="form-group">
					<label for="testSel">Test Disponibles</label>
					<select class="form-control" id="testSel" name="testSel">
						<option selected><?php if(isset($_SESSION['tituloSave'])){echo $_SESSION['tituloSave'];unset($_SESSION['tituloSave']);}else { echo "Seleccione el test";} ?></option>
					<?php  $titulos = getTitulos(); while($row_a = $titulos->fetch_row()){ ?>  
                    	<option value="<?php echo $row_a[0];?>"><?php echo $row_a[1]; ?></option>
                    <?php }?>
						</select>
				</div>				  
				  <button type="submit" class="btn btn-primary">Consultar</button>
				</form>
				  <hr>
				  <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
					<div class="form-group">
				<label for="exampleFormControlSelect2">Seleccione una pregunta a Editar</label>
				<select multiple class="form-control" id="preguntasEditar" name="preguntasEditar">
					<?php  if(isset($preguntas)){ while($row_b = $preguntas->fetch_row()){ ?>
				  	<option value="<?php echo $row_b[0]; ?>"><?php echo $row_b[1] ?></option>
					<?php  }  } ?>
				</select><br>
						<?php if(isset($_SESSION['botonTrue'])){ echo "<button type='submit' class='btn btn-primary'>Editar</button>"; unset($_SESSION['botonTrue']); } ?>
			  </div>
				  </form>
				  
			</div>
			
		</div>
    </div>
<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="modalError">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
		<div class="modal-header">
			<h4 id="smallModal" class="modal-title">Aviso:</h4>
			<button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
		</div>
		<div class="modal-body">
			<?php if(isset($_SESSION['mnsjError'])){echo $_SESSION['mnsjError'];  unset($_SESSION['mnsjError']);}?>
		</div>
    </div>
  </div>
</div>
  </body>
</html>