<?php  
   session_start();
   if($_FILES['file-1']['name'] != ''){  
    $tmp = explode(".", $_FILES['file-1']['name']);
    $extension = end($tmp);  
    $allowed_type = array("txt");  
    if(in_array($extension, $allowed_type)){  
      $new_name = "u".$_SESSION['nControl'].".". $extension;
      $path = "img/" . $new_name;

      try {
        unlink($path);
      } catch (Exception $e) {
          echo 'Excepción capturada: ',  $e->getMessage(), "\n";
      }
     if(move_uploaded_file($_FILES['file-1']['tmp_name'], $path)){  
      echo '  
           <!div class="col-md-8"-->       
                <!--img src="'.$path.'" class="img-responsive" /-->  
                <img class="img-responsive img-portfolio img-hover" src="'.$path.'" alt="Foto de perfil">
           <!--/div-->  
           <!--div class="col-md-4">  
                <button type="button" data-path="'.$path.'" id="remove_button" class="btn btn-danger">x</button>  
           </div-->  
           ';  
     }  
    }else{  
         echo '<script>alert("Formato de archivo invalido")</script>';  
    }  
   }else{  
    echo '<script>alert("Por favor seleccione un archivo png")</script>';  
   }  
 ?> 