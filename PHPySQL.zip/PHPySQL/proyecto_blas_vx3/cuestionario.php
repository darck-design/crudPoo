<?php
  session_start();

  require 'funcs/conexion.php';
  require 'funcs/funcs.php';
  require 'funcs/consultas.php';
  require 'funcs/constantes.php';

  if(!isset($_SESSION['logueado']) && !$_SESSION['logueado']){
    header("location: logout.php");
  }
  $terminar = 0;
  $url_linker = 0;

	if(!empty($_POST))
	 {
	 	$terminar = 0;
		if(isset($_POST['calificar'])){
			
			$testId = limpiarCadena($mysqli->real_escape_string($_SESSION['tit']));
	 		$ListaDeTestId = getListaDeIds($testId);
			
			
			if(isset($_POST['exampleRadios'])){
				$valor = $_POST['exampleRadios'];	
			}else{
				header("location: cuestionario.php");
			}
			$respuestaCorrecta = getRespuestaCorrecta($ListaDeTestId[$_SESSION['contador']]);
			if($valor == $respuestaCorrecta){
				$_SESSION['band'] = 1;
				$_SESSION['mensajes'] = 1;
				$_SESSION['answerCorrectas'] = $_SESSION['answerCorrectas']+1;
			}else{
				$_SESSION['mensajes'] = 2;	
				$_SESSION['band'] = 0;
				$_SESSION['answerInCorrectas'] = $_SESSION['answerInCorrectas'] +1;
			}
			
		}else if(isset($_POST['siguiente'])){
				$_SESSION['band'] = 0;
				$_SESSION['contador']=$_SESSION['contador']+1;
				$_SESSION['mensajes'] = 0;

				$testId = limpiarCadena($mysqli->real_escape_string($_SESSION['tit']));
				$ListaDeTestId = getListaDeIds($testId);

			if($_SESSION['contador'] < $_SESSION['totalElementos']){
				$pregunta = getPregunta($ListaDeTestId[$_SESSION['contador']]);
				$respuestaCorrecta = getRespuestaCorrecta($_SESSION['contador']);
			}else{
				$_SESSION['band'] = 0;
			}

			if($_SESSION['contador'] >= ($_SESSION['totalElementos'])){
				$_SESSION['band'] = 0;
				$_SESSION['modalTe']=1;
				$terminar = 1;
			}
		}
	 }else{
		$testId = limpiarCadena($mysqli->real_escape_string($_SESSION['tit']));
		$ListaDeTestId = getListaDeIds($testId);
		$terminar = 1;
		$url_linker = 1;
	}
	if(isset($_REQUEST['titulo'])){
		$_SESSION['band'] = 0;
		$_SESSION['mensajes']=0;
		$_SESSION['tit'] = $_REQUEST['titulo']; 
		$_SESSION['answerCorrectas'] = 0;
		$_SESSION['answerInCorrectas'] = 0;
		$_SESSION['modalTe']=0;
		$totalDePreg = getTotalT($_REQUEST['titulo']);
		if($totalDePreg==0){
				$_SESSION['existeTests']=1;
			header("location: cuenta_cliente.php");
		}
		$testId = limpiarCadena($mysqli->real_escape_string($_REQUEST['titulo']));
	 	$ListaDeTestId = getListaDeIds($testId);
		$_SESSION['totalElementos'] = count($ListaDeTestId);
		$_SESSION['contador']=0;
		$pregunta = getPregunta($ListaDeTestId[$_SESSION['contador']]);
	}

	if($_SESSION['contador'] < $_SESSION['totalElementos']){
			$pregunta = getPregunta($ListaDeTestId[$_SESSION['contador']]);
			$respuestas = getRespuestas($ListaDeTestId[$_SESSION['contador']]);
			$respuestaCorrecta = getRespuestaCorrecta($_SESSION['contador']);
			if($pregunta==NULL){
				$_SESSION['band'] = 0;
			}	
	}else {
		$_SESSION['band'] = 0;
		$terminar = 1;
	}
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
	  
	  if($_SESSION['modalTe']==1){
		  echo "<script type='text/javascript'>
           $(document).ready(function() {
    		$('#finDeTest').modal('show'); 
				});
        </script>";
	  }
	  
    ?>
  </head>
  <body>
    <?php
      require_once 'menu.php';
      imprimirMenu("cc");
    ?>
    <div class="container" >
			<?php

				if($terminar==0){

			?>
		    <div class="container" >
				  <p class="font-weight-bold text-center">
					  <?php 
					  $row_a = $pregunta->fetch_row();
					  echo $row_a[0]." ";
					  ?>
				  </p>
		    </div>
			<form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" style="text-align: center;">
				<?php  foreach ($respuestas as $respuesta){ ?>
				
					<div class="form-check">
					  <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="<?php echo $respuesta['id']; ?>">
					  <label class="form-check-label" for="exampleRadios2">
						<?php echo $respuesta['respuesta']; ?>
					  </label>
					</div> <br>
				
				<?php } ?>
				<div class="container" >
				<div class="row">
				<div class="col-sm-6" >		
				<?php
					if($_SESSION['band']==1){
						echo "<button type='submit' class='btn btn-success btn-lg btn-block active' value='Calificar' name='calificar' disabled>Calificar</button>";
						
					}else{
						echo "<button type='submit' class='btn btn-success btn-lg btn-block active' value='Calificar' name='calificar' >Calificar</button>";	
					}					
						?>
				</div>
				<div class="col-sm-6" >
						<?php
					if($_SESSION['band']==1){
						echo "<button type='submit' class='btn btn-success btn-lg btn-block active'  value='Siguiente' name='siguiente'>Siguiente</button>";
						
					}else{
						echo "<button type='submit' class='btn btn-success btn-lg btn-block active'  value='Siguiente' name='siguiente' disabled>Siguiente</button>";
					}					
						?>
						</div>
					</div>
    			</div>
		</form><br><br>
    </div>
	  <br/>	  
	  <div class="container" style="text-align: center;">
		  <?php
		  	switch($_SESSION['mensajes']){
				case 1:
					echo "<div class='alert alert-success' role='alert'>Respuesta Correcta, por favor presione Siguiente</div>";
						
					break;
				case 2:
						echo "<div class='alert alert-danger' role='alert'>Respuesta Incorrecta Por favor intente de Nuevo</div>";
					break;
			}
		  ?>
		  <a class="btn btn-primary" href="cuenta_cliente.php" role="button">Regresar </a>
	  </div>

	  <?php
	  	}else if($url_linker == 1)
	  		header("location: cuenta_cliente.php");
	  ?>
	  
	  <div class="modal fade" id="finDeTest" role="dialog">
	      <div class="modal-dialog">
	        <!-- Modal content-->
	        <div class="modal-content">
	          <div class="modal-header">
	            <button type="button" class="close" data-dismiss="modal">&times;</button>
	            <h4 class="modal-title">Listo ha Concluido el Test!!</h4>
	          </div>
	          <div class="modal-body" style="text-align: center;">
	            <p>
	              Respuestas Contestado Correctamente = <?php echo $_SESSION['answerCorrectas'];  ?><br/>
				  Respuestas Fallidas  = <?php echo $_SESSION['answerInCorrectas']; ?><br/>
				
					Por favor presione Aceptar para ir a la lista de Test. 
	            </p>
	          </div>
					<div class="modal-footer">
					<a href="cuenta_cliente.php" class="btn btn-primary btn-sm active" role="button" aria-pressed="true">Aceptar</a>
				  </div>
	        </div>
	      </div>
    </div>
	  
  </body>
</html>