<?php
  session_start();
  
  require 'funcs/conexion.php';
  require 'funcs/funcs.php';

  if(isset($_SESSION['logueado']) && $_SESSION['logueado']){
    header("location: logout.php");
  }
  
  $errors = array();
  
  if(!empty($_POST))
  {
    $usuario = limpiarCadena($mysqli->real_escape_string($_POST['userName']));
    $password = limpiarCadena($mysqli->real_escape_string($_POST['password']));
    if(isset($_POST['tipoUser']))
      $tipoUser = $_POST['tipoUser'];
    else
      $tipoUser = 1;
    
    if(isNullLogin($usuario, $password))
      $errors[] = "Debe llenar todos los campos";
      
    if(count($errors)==0){
        $logear = login($usuario, $password, $tipoUser);

        $errors[] = $logear;
    }
  }
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
    ?>
    <link rel="stylesheet" href="css/estilo_login.css">
  <body>
    <?php
      require_once 'menu.php';
      imprimirMenu("inicio");
    ?>
    <div class="login">
      <h1>Iniciar sesión</h1>
      <form method="post" action="">
        <div id="signupalert" style="display:none;" class="alert alert-danger">
          <p>Error:</p>
          <span></span>
        </div>
        <?php echo resultBlock($errors); ?>
        <p><input type="text" name="userName" value="" placeholder="Nombre de usuario"></p>
        <p><input type="password" name="password" value="" placeholder="Contraseña"></p>
        <p class="tipoUser">
          <label>
            <input type="checkbox" name="tipoUser" id="tipoUser">
            Soy administrador
          </label>
        </p>
        <p class="submit"><input type="submit" name="commit" value="Iniciar sesión"></p>
      </form>
    </div>
  </body>
</html>