<?php
  session_start();

  require 'funcs/conexion.php';
  require 'funcs/funcs.php';
  require 'funcs/consultas.php';

  if(!isset($_SESSION['logueado']) && !$_SESSION['logueado'] || !isset($_SESSION['admin_logueado']) && !$_SESSION['admin_logueado']){
    header("location: logout.php");
  }else{

    if(isset($_POST)){
      if(!empty($_POST['username']) && !empty($_POST['titulo'])){
        $usern = $_POST['username'];
        $tes = $_POST['titulo'];

        echo "$usern y $tes";
      }else{
        echo "No selecciono un dato";
      }
    }
    
  }
?>