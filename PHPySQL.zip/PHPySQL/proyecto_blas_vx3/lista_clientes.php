<?php
  session_start();
  include('funcs/conexion.php');
  require 'funcs/consultas.php';

  if(isset($_SESSION['logueado']) && $_SESSION['logueado'] && isset($_SESSION['admin_logueado']) && $_SESSION['admin_logueado']){
    $perfiles=consultarPerfiles();
  }else{
      header("location: index.php");
      
  }
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
    ?>
  </head>
  <body>
    <?php
      require_once 'menu.php';
      imprimirMenu("lc");
    ?>
      
    <div class="container" >
      <h3>Lista de clientes registrados</h3>
      <div id="tab">
        <table class="table table-hover" >
          <thead>
            <tr>
              <th>Nombre de Usuario</th>
              <th>Fecha inicio</th>
              <th>Fecha expira</th>
              <th>Eliminar usuario</th>
            </tr>
          </thead>

          <tbody>
            <?php foreach($perfiles as $perfil){ ?>
              <tr>
                <td><?php echo $perfil['username']; ?></td>
                <td><?php echo $perfil['fechaini']; ?></td>
                <td><?php echo $perfil['fechafin']; ?></td>
                <td>
                  <form action="eliminarUsuario.php" method="POST">
                    <input type="text" name="username" class='hide' value="<?php echo $perfil['username']; ?>">
                    <input type="submit" class='btn btn-danger' value="Eliminar">
                  </form>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </body>
</html>