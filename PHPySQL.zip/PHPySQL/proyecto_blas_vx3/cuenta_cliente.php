<?php
  session_start();

  require 'funcs/conexion.php';
  require 'funcs/funcs.php';
  require 'funcs/consultas.php';
	require 'funcs/constantes.php';

  if(!isset($_SESSION['logueado']) && !$_SESSION['logueado'] || (isset($_SESSION['admin_logueado']) && $_SESSION['admin_logueado'])){
    header("location: logout.php");
  }else{
    $tests=consultarTestsasignados($_SESSION['id_usuario']);
    $testsna=consultarTestsNoasignados($_SESSION['id_usuario']);
    $comFecha = getCurrentDay($_SESSION['id_usuario']);
  }
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
  	  if($_SESSION['existeTests']==1){
  		  echo "
  		  <script type='text/javascript'>
             $(document).ready(function() {
      		$('#avisoTest').modal('show'); 
  				});
        </script>";
  		  $_SESSION['existeTests']=0;
  	  }elseif(isset($_SESSION['avisoTime'])){
        echo "
        <script type='text/javascript'>
             $(document).ready(function() {
          $('#avisoFecha').modal('show'); 
          });
        </script>";
      }
    ?>
  </head>
  <body>
    <?php
      require_once 'menu.php';
      imprimirMenu("cc");
    ?>
    
    <div class="container">
      <div class="row" style="text-align: center;">
        <div class="col-sm-12">
          <h2>Bienvenido <?php echo $_SESSION['usuario']; ?></h2><br><br>
          <h3>Lista de tests</h3>
          <div id="tab">
            <table class="table table-hover" style="text-align: left;" >
              <thead>
                <tr>
                  <th>Titulo</th>
                  <th>Contestar</th>
                </tr>
              </thead>

              <tbody>
                <?php foreach($tests as $test){ ?>
                  <tr>
                    <td><?php echo $test['titulo']; ?></td>
                    <td>
                      <form action="cuestionario.php" method="POST">
                        <input type="text" name="titulo" class='hide' value="<?php echo $test['id_test']; ?>">
                        <input type="submit" class='btn btn-success' value="Contestar">
                      </form>
                    </td>
                  </tr>
                <?php } ?>
                 <?php foreach($testsna as $test){ ?>
                  <tr>
                    <td><?php echo $test['titulo']; ?></td>
                    <td>
                        <input type="text" name="titulo" class='hide' value="<?php echo $test['titulo']; ?>">
                        <input type="submit" class='btn btn-info' data-toggle="modal" data-target="#info" value="Comprar">
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal para el test -->
    <div class="modal fade" id="info" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title">Adquirir</h2>
          </div>
          <div class="modal-body" style="text-align: center;">
            <img src="img/adquirir.png">
            <p>
              Contacte con el administrador para habilitar el test que desea<br>
              Llame al número: 971-213-1123
            </p>
          </div>
        </div>
      </div>
    </div>
	  <div class="modal fade" id="avisoTest" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title">Atención!!</h2>
          </div>
          <div class="modal-body" style="text-align: center;">
            <img src="img/oops.png">
            <p>
              Upsss!! Al parecer el test no tiene preguntas!!<br>
				      por favor pongase en contacto con el Administrador!!!.
            </p>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="avisoFecha" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title">Advertencia!!</h2>
          </div>
          <div class="modal-body" style="text-align: center;">
            <img src="img/expirar.png">
            <p>
              <?php if(isset($_SESSION['avisoTime'])){echo $_SESSION['avisoTime'];unset($_SESSION['avisoTime']);} ?>
            </p>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>