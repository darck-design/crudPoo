<?php
  session_start();

  require 'funcs/conexion.php';
  require 'funcs/funcs.php';
  require 'funcs/consultas.php';

  if(!isset($_SESSION['logueado']) && !$_SESSION['logueado'] || !isset($_SESSION['admin_logueado']) && !$_SESSION['admin_logueado']){
    header("location: logout.php");
  }else{
    $perfiles=consultarPerfiles();
    $tests=consultarTests();
  }
?>

<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
    ?>
  </head>
  <body>
    <?php
      require_once 'menu.php';
      imprimirMenu("ca");
    ?>
    <div class="container">
      <p>Seleccione un usuario y el test que le desea asignar</p>
      <form action="asignar.php" method="POST">
        <div class="form-group " >
          <label>Usuario:</label>
          <select class="container-4" name="clientes">
            <option value=" --- " selected="selected">Seleccione usuario</option>
            <?php foreach($perfiles as $perfil){ ?>
              <option value="<?php echo $perfil['username']; ?>" ><?php echo $perfil['username']; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="form-group " >
          <label>Test:</label>
          <select class="container-4" name="tests">
            <option value=" --- " selected="selected">Seleccione test</option>
            <?php foreach($tests as $test){ ?>
              <option value="<?php echo $test['titulo']; ?>" ><?php echo $test['titulo']; ?></option>
            <?php } ?>
          </select>
        </div>
        <input type="submit" class="btn btn-info" value="Asignar">
      </form>
    </div>
  </body>
</html>