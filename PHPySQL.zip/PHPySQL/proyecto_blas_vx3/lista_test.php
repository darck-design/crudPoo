<?php
  session_start();
  include('funcs/conexion.php');
  require 'funcs/consultas.php';

  if(isset($_SESSION['logueado']) && $_SESSION['logueado'] && isset($_SESSION['admin_logueado']) && $_SESSION['admin_logueado']){
    $tests=consultarTests();
  }else{
      header("location: index.php");
      
  }
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
    ?>
  </head>
  <body>
    <?php
      require_once 'menu.php';
      imprimirMenu("lt");
    ?>
      
    <div class="container" >
      <h3>Lista de test creados</h3>
      <div id="tab">
        <table class="table table-hover" >
          <thead>
            <tr>
              <th>Titulo</th>
              <th>Numero de preguntas</th>
              <th>Eliminar test</th>
            </tr>
          </thead>

          <tbody>
            <?php foreach($tests as $test){ ?>
              <tr>
                <td><?php echo $test['titulo']; ?></td>
                <td><?php echo $test['totalp']; ?></td>
                <td>
                  <form action="eliminarTest.php" method="POST">
                    <input type="text" name="titulot" class='hide' value="<?php echo $test['titulo']; ?>">
                    <input type="submit" class='btn btn-danger' value="Eliminar">
                  </form>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </body>
</html>