<?php
  session_start();

  require 'funcs/conexion.php';
  require 'funcs/funcs.php';
  require 'funcs/consultas.php';
  require 'funcs/constantes.php';

  if(!isset($_SESSION['logueado']) && !$_SESSION['logueado'] || !isset($_SESSION['admin_logueado']) && !$_SESSION['admin_logueado']){
    header("location: logout.php");
  }
  $errors = array();
  $errort = array();
  $errortest = array();
  $re = -1;
  $mensaje = "";

  if(!empty($_POST)){

    if(isset($_POST['regis'])){
      if(!empty($_POST['usuario']) && !empty($_POST['pwd']) && !empty($_POST['datei']) && !empty($_POST['datef'])){
        
        $usuario = limpiarCadena($mysqli->real_escape_string($_POST['usuario']));
        $password = limpiarCadena($mysqli->real_escape_string($_POST['pwd']));
        $fi = $_POST['datei'];
        $ff = $_POST['datef'];
        if(isNullLogin($usuario, $password))
          $errors[] = "Debe llenar todos los campos";
        else{
          if(usuarioExiste($usuario)){
            $errors[] = "El nombre $usuario ya existe";
          }
          if(count($errors)==0){
              $pass_hash = hashPassword($password);
              $registro = registraUsuario($usuario, $pass_hash, 1, 2, $fi, $ff);
              if($registro > 0){
                $re = 1;
                $mensaje = "Registro exitoso";
              }else{
                $errors[] = "Error al registrar";
              }
          }
        }
      }else
        $errors[] = "Debe llenar todos los campos";
    }else if(isset($_POST['agregartitulo'])){
      $titulo = limpiarCadena($mysqli->real_escape_string($_REQUEST['titulo_c']));
      if(!existeTest($titulo)){
        $resultado = setTitulo($titulo);
        if($resultado!=0){
          $re = 1;
          $mensaje = "Se agrego el titulo correctamente";
        }else{
          $re = 0;
          $mensaje = "No se ha podido inserar el titulo a la BD";
        }
      }else{
        $re = 0;
        $mensaje = "Ya existe una encuesta con ese nombre";
      }
      
    }else if(isset($_POST['agregar_preg'])){
		  $pregunta = limpiarCadena($mysqli->real_escape_string($_REQUEST['preguntas_c']));
			$respuestaOrig = limpiarCadena($mysqli->real_escape_string($_REQUEST['respuesta_orig']));
			$respuestaAl1 = limpiarCadena($mysqli->real_escape_string($_REQUEST['respuesta_alea1']));
			$respuestaAl2 = limpiarCadena($mysqli->real_escape_string($_REQUEST['respuesta_alea2']));
			$elementosResp = array();
			$valPreg = limpiarCadena($mysqli->real_escape_string($_REQUEST['id_val']));
			for($i=0;$i<$valPreg;$i=$i+1){
				
				if($_REQUEST['answer'.$i]!=NULL){
					
					$elementosResp[$i] = limpiarCadena($mysqli->real_escape_string($_REQUEST['answer'.$i]));
				}		
			}
			$id_test = $_REQUEST['id_Titulo'];	
			$resultadoP = setQuestion($id_test,$pregunta,$elementosResp,$respuestaOrig,$respuestaAl1,$respuestaAl2,$valPreg);
			if($resultadoP){
				header("Location: cuenta_administrador.php");
			}else{
        $re = 0;
        $mensaje = "Error al agregar pregunta";
      }
    }else if(isset($_POST['asignart'])){
      $id_user = $_REQUEST['id_User'];
      $id_test = $_REQUEST['id_titulot'];  
      $resultadoP = setTestUser($id_test,$id_user);
      if($resultadoP==-1)
        $errort[] = "Error en la BD: No se pudo asignar el test";
      else if($resultadoP==0)
        $errort[] = "El test ya ha sido asignado al usuario";
    }else if(isset($_POST['agregartest'])){
      
      if(isset($_POST['myFile']) && !empty($_POST['myFile'])){
        $nombre = $_POST['myFile'];
        //echo "El nombre de archivo es: $nombre <br>";
        $archivo = fopen("$nombre","r") or die("problemas al abrir archivo.txt");
        
        $c = 0; //contador de campos/atributos en cada linea
        $lineauno = 1; //contador de lineas - si es la primera linea entonces es el titulo
        
        $titulo_t = "";
        $preguntaArchivo = "";
        $respuestaCArchivo = "";
        $opcionRArchivo = "";

        $bandera = 0; //indica si el titulo de la pregunta coincide con el de la encuesta
        $mensaje = "";

        $nuevaEncuesta = 1;

        //verificamos si selecciono crear encuesta nueva o solo subir preguntas, por default se creara
        if(isset($_POST['crear'])){
          $nuevaEncuesta = $_POST['crear'];
        }

        while(!feof($archivo) && $bandera!=-1){
          $traer = fgets($archivo);
          //$saltolinea = nl2br($traer);
          $saltolinea = trim($traer);

          if(!empty(trim($traer))){ //si la linea que se lee no esta vacio entonces se procesa
            
            if($lineauno == 1){ //se lee el titulo para la encuesta
              $titulo_t = trim($traer);

              $titulo_t2 = limpiarCadena($mysqli->real_escape_string($titulo_t));

              if (!preg_match("/^[a-zA-Z0-9 ñ.áéíóúäëïöü]{3,63}$/", $titulo_t2)) { 
                $mensaje = "Error al leer el archivo";
                $errortest[] = "El archivo no cumple con la nomenclatura<br>Revise el titulo";
                $re = 0;
                $bandera = -1;
                break;
              }else{

                $id_titulo_auxiliar = existeTest($titulo_t2);

                if($nuevaEncuesta==1){
                  if($id_titulo_auxiliar == 0){
                    $id_titulo = setTitulo($titulo_t2);
                    if($id_titulo!=0){
                      $re = 1;
                      $mensaje = "Se agrego el titulo correctamente";
                    }else{
                      $mensaje = "Error al crear La encuesta";
                      $errortest[] = "No se pudo añadir el titulo en la BD";
                      $re = 0;
                      $bandera = -1;
                      break;
                    }
                  }else{
                    $re = 0;
                    $mensaje = "Ya existe una encuesta con ese nombre";
                    $bandera = -1;
                    break;
                  }
                }else{
                  if($id_titulo_auxiliar!=0){
                     $id_titulo = $id_titulo_auxiliar;
                  }else{
                    $re = 0;
                    $mensaje = "No existe una encuesta con ese nombre";
                    $bandera = -1;
                    break;
                  }
                }
              }

            }else{ //se procesa la pregunta y las respuestas
              $datos=explode(",",$saltolinea);
              foreach($datos as $dato){ // se recorre la linea

                if($c==0){ //se compara si los titulos coinciden
                  //echo "$titulo_t - $dato";
                  if(strcmp($titulo_t, $dato) === 0){
                    $bandera = 1;
                  }else{ //se detendra el almacenamiento a la base de datos para que asi, solo copie desde esta linea ya corregido y se mantenga el orden de las preguntas
                    if($lineauno==2){
                      $mensaje = "Error en la linea $lineauno del archivo";
                      $errortest[] = "Solo se creo el test y no se agregaron las preguntas";
                    }else{
                      $auxiliar = $lineauno - 1;
                      $errortest[] = "El titulo de la encuesta es de otra encuesta<br>El test se creo y se guardó hasta la linea $auxiliar";
                      $mensaje = "Error en la linea $lineauno del archivo";
                    }
                    
                    $re = 0;
                    $bandera = -1;
                    break;
                  }
                }else if($bandera == 1){ //si los titulos coinciden se agrega la pregunta

                  if($c==1){ //se inserta la pregunta a la bd
                    $preguntaArchivo = limpiarCadena($mysqli->real_escape_string($dato));
                    if($preguntaArchivo != ""){
                      $id_pregunta = setPregunta($id_titulo,$preguntaArchivo);
                      if($id_pregunta == 0){
                        $mensaje = "Error al insertar la pregunta";
                        $errortest[] = "No se pudo añadir la pregunta a la BD";
                        $re = 0;
                        $bandera = -1;
                        break;
                      }
                    }else{
                      $mensaje = "Error en la linea $lineauno no se pudo leer la pregunta";
                      $errortest[] = "La pregunta esta vacía<br>Se guardo hasta esta linea";
                      $re = 0;
                      $bandera = -1;
                      break;
                    }
                  }else if($c==2){ //se inserta la respuesta correcta en la bd
                    $respuestaCArchivo = limpiarCadena($mysqli->real_escape_string($dato));
                    if($respuestaCArchivo != ""){
                      $id_respuesta = setRespuesta($id_titulo,$id_pregunta,$respuestaCArchivo,1);
                      if($id_respuesta == 0){
                        $mensaje = "Error al insertar la respuesta";
                        $errortest[] = "No se pudo añadir la respuesta a la BD";
                        $re = 0;
                        $bandera = -1;
                        break;
                      }
                    }else{
                      $mensaje = "Error en la linea $lineauno no se pudo leer la respuesta";
                      $errortest[] = "La respuesta correcta está vacía<br>Se guardo hasta esta linea";
                      $re = 0;
                      $bandera = -1;
                      break;
                    }
                  }else if($c>2){ //se inserta la opcion de respuesta en la bd
                    $opcionRArchivo = limpiarCadena($mysqli->real_escape_string($dato));
                    if($opcionRArchivo != ""){
                      $id_respuesta = setRespuesta($id_titulo,$id_pregunta,$opcionRArchivo,0);
                      if($id_respuesta == 0){
                        $mensaje = "Error al insertar la respuesta";
                        $errortest[] = "No se pudo añadir la respuesta a la BD";
                        $re = 0;
                        $bandera = -1;
                        break;
                      }
                    }else{
                      $mensaje = "Error en la linea $lineauno no se pudo leer la respuesta";
                      $errortest[] = "La respuesta está vacía<br>Se guardo hasta esta linea";
                      $re = 0;
                      $bandera = -1;
                      break;
                    }
                  }
                } 
                $c++;
              } //se termina de recorrer la linea

              if($bandera!=-1){ //se reinicia el contador de campos/atrubutos para una nueva linea
                $c = 0;
                $bandera = 0;
              }
              //echo "<p />";
            } //se termina de leer una linea de preguntas y respuestas
            $lineauno++;
          }//termina si la linea esta vacia
        }//termina el while

        if($bandera != -1){
          $mensaje = "La encuesta se ha subido exitosamente";
          $re = 1;
        }

      }else
        echo "<script>alert('Por favor, Seleccione un archivo .txt')</script>";
    } 
  }
  $_SESSION['cont'] = 1;
  $titulos = getTitulos();
  $perfiles= getUsuarios();
  $datosFechaFin = getUsuariosFin(); 
  $totalFecha =  $datosFechaFin->num_rows;
  

?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <?php
      require_once 'header.php';
    ?>
    <script src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
  </head>
  <body>
    <?php
      if($re==1)
        echo "<script type='text/javascript'>
          $(window).load(function() {
              $('#exito').modal('show');
          });
          </script>";
      else if($re==0)
        echo "<script type='text/javascript'>
          $(window).load(function() {
              $('#fail').modal('show');
          });
          </script>";
    ?>
    <?php
      require_once 'menu.php';
      imprimirMenu("ca");
    ?>
    <div class="container">
      <div class="row" style="text-align: center;">
        <div class="col-sm-4">
          <ul style="text-align: center; list-style:none;">
            <h2>Administrar usuarios</h2><br>
            <li><a class="btn btn-info" href="lista_clientes.php">Lista de usuarios</a></li><br>
            <div id="signupalert" style="display:none" class="alert alert-danger">
              <p>Error:</p>
              <span></span>
            </div>
            <?php echo resultBlock($errort); ?>
            <li><a class="btn btn-info" href="#" data-toggle="modal" data-target="#atest">Asignar test</a></li><br>
            <li>
            <button type="button" class="btn btn-primary" data-container="body" data-toggle="popover" data-placement="bottom" data-content="<?php echo "<label for='select'>Usuarios Finalizados :</label><select multiple class='form-control' id='select'>"; while($row_a = $datosFechaFin->fetch_row()){ echo "<option>$row_a[0]</option>";}echo "</select>"; echo "<a href='lista_clientes.php' class='badge badge-info'>Ir a Borrar </a>"; ?>">Notificaciones <span class="badge badge-light"><?php echo $totalFecha; ?></span></button>
            </li>
          </ul>
        </div>
        <div class="col-sm-4">
          <h2>Crear usuario</h2><br>
          <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
            <div id="signupalert" style="display:none" class="alert alert-danger">
              <p>Error:</p>
              <span></span>
            </div>
            <?php echo resultBlock($errors); ?>
            <div class="form-group">
              <label for="usuario">Nombre de usuario:</label>
              <input type="text" class="form-control" name="usuario">
            </div>
            <div class="form-group">
              <label for="pwd">Contraseña:</label>
              <input type="password" class="form-control" name="pwd">
            </div>
            <div class="form-group">
              <label for="datei">Fecha de inicio:</label>
              <input name="datei" type="date">
            </div>
            <div class="form-group">
              <label for="datef">Fecha de expiración:</label>
              <input name="datef" type="date">
            </div>
            <input type="submit" class='btn btn-success' value="Registrar" name="regis">
          </form>
        </div>

        <div class="col-sm-4">
          <ul style="text-align: center; list-style:none;">
            <h2>Administrar test</h2><br>
            <li><button type="button" class="btn btn-info" data-toggle="modal" data-target="#atitulo">Agregar titulo</button></li><br>
            <li><button type="button" class="btn btn-info" data-toggle="modal" data-target="#apreg">Agregar preguntas</button></li><br>
            <li><a class="btn btn-info" href="lista_test.php">Lista de test</a></li><br>
            <li><a class="btn btn-info" href="editar.php">Modificar Preguntas</a></li><br>
            <li><button type="button" class="btn btn-info" data-toggle="modal" data-target="#addtest">Subir test</button></li><br>
          </ul>
        </div>
      </div>
      
      <!-- Modal para asignar test -->
      <div class="modal fade" id="atest" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Asignación de test</h4>
            </div>
            <div class="modal-body" style="text-align: center;">
              <p>Seleccione un usuario y el test que le desea asignar</p>
              <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
                <div class="form-group " >
                  <label>Usuario:</label>
                  <select class="form-control" id="id_User" name="id_User">
                    <?php while($row_a = $perfiles->fetch_row()){ ?>
                    
                      <option value="<?php echo $row_a[0];?>"><?php echo $row_a[1]; ?></option>
                    
                    <?php }?>
                  </select>
                </div>
                <div class="form-group " >
                  <label>Test:</label>
                  <select class="form-control" id="id_titulot" name="id_titulot">
                    <?php while($row_a = $titulos->fetch_row()){ ?>
                    
                      <option value="<?php echo $row_a[0];?>"><?php echo $row_a[1]; ?></option>
                    
                    <?php }?>
                  </select>
                </div>
                <input type="submit" class="btn btn-success" name="asignart" value="Asignar">
              </form>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal para agregar titulo -->
      <div class="modal fade" id="atitulo" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Titulo</h4>
            </div>
            <div class="modal-body">
          <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
          <div class="form-group">
            <label for="usuario">Ingrese el titulo</label>
            <input type="text" class="form-control" name="titulo_c" required autofocus autocomplete="off">
          </div>
          <input type="submit" class='btn btn-success' value="Agregar" name="agregartitulo">
          </form>
        </div>
          </div>
        </div>
      </div>

      <!-- ********************************** Codigo nuevo 15/07/2018 ************************************ -->
      <!-- Modal para agregar test -->
      <div class="modal fade" id="addtest" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Agregar encuesta</h4>
            </div>
            <div class="modal-body">
              <label>La nomenclatura del archivo de texto debe ser:</label><br>
              <p>Titulo del test<br>
              Titulo,pregunta,respuesta-correcta,opcion1-respuesta,opcion2-respuesta,...,opcionN-respuesta<br>...<br>.<br>.<br>.</p><br>
              
              <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
                <input type="radio" name="crear" value="1"> Subir y crear encuesta nueva<br> 
                <input type="radio" name="crear" value="2"> Subir preguntas de una encuesta ya creada<br><br>
                Seleccione un archivo: <input type="file" name="myFile" accept=".txt"><br><br>
                <input type="submit" class='btn btn-success' value="Subir" name="agregartest">
              </form>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal actualizacion sin exito -->
      <div id="fail" class="modal fade" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-body">
              <center>
                <img src='img/error_15261.png' style="width: 160px; height: 100px;"><br>
                <h2><?php echo "$mensaje";  ?></h2>
                <?php 
                  foreach ($errortest as $error){
                    echo "<h3>$error</h3>";
                  }
                ?>
              </center>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal actualizacion exitoso -->
      <div id="exito" class="modal fade" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-body">
              <center>
                <img src='img/ok.png'><br>
                <h2><?php echo "$mensaje";  ?></h2>
              </center>
            </div>
          </div>
        </div>
      </div>

      <!-- ********************************************************************** -->

      <!-- Modal para las preguntas -->
      <div class="modal fade" id="apreg" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Preguntas</h4>
            </div>
            <div class="modal-body">
              <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST">
                <div class="form-group">
                  <label for="id_Titulo">Seleccione su titulo:</label>
                
                  <select class="form-control" id="id_Titulo" name="id_Titulo">
                    <?php  $titulos = getTitulos(); while($row_a = $titulos->fetch_row()){ ?>
                    
                    <option value="<?php echo $row_a[0];?>"><?php echo $row_a[1]; ?></option>
                    
                    <?php }?>
                  </select>
                </div>
				  
                <div class="form-group">
                  <label for="usuario">Ingrese pregunta:</label>
                  <input type="text" class="form-control" name="preguntas_c" required autofocus autocomplete="off">
                </div>
				  
				 <div class="form-group">
                  <label for="respuestaOrig">Ingrese la respuesta Correcta:</label>
                  <input type="text" class="form-control" name="respuesta_orig" required autofocus autocomplete="off">
                </div>
				  <div class="form-group">
                  <label for="respuestaalea1">Ingrese opción de respuesta 1:</label>
                  <input type="text" class="form-control" name="respuesta_alea1" required autofocus autocomplete="off">
                </div>
				  <div class="form-group">
                  <label for="respuestaalea2">Ingrese opción de respuesta 2:</label>
                  <input type="text" class="form-control" name="respuesta_alea2" required autofocus autocomplete="off">
                </div>
				  <br> 
				  <div align="center">					
						<div class="row">
							<div class="col-sm-6" >
								<div class="form-group">
							<select class="form-control" id="id_val" name="id_val">
							  <?php $i=2; while($i<12){ ?>							
								<option value="<?php echo $i; ?>"><?php echo $i; ?></option>							
								<?php $i=$i+1; }?>
							</select>
						</div>	
										</div>
							<div class="col-sm-6" >
					<button type="button" class="btn btn-outline-primary" onclick="iniciar()">Nuevas Respuestas</button>
								</div>
						</div>
				 	</div>			 
				 	<div class="form-group">
				 		<div id="cajasTexto">
						
						</div>
				 	</div>
                <input type="submit" class='btn btn-success' value="Agregar" name="agregar_preg">
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
	   <script type="text/javascript">	

      $(function () {$('[data-toggle="popover"]').popover({html:true});})

		  function iniciar(){
			  limpiar();
			  myFunction();
		  }
		  function limpiar(){
			   var y = document.getElementById('cajasTexto');
			   while(y.firstChild){
					y.removeChild(y.firstChild);
					}
		  }
		  function myFunction() {
			  var y = document.getElementById('id_val').value; 
			for(var i=0; i<y; i++){
				var modal = document.getElementById('cajasTexto');
				var x = document.createElement("INPUT");
				x.setAttribute("type", "text");
			  	x.setAttribute("placeholder","Ingrese opción de respuesta"+(i+3));
			  	x.setAttribute("class","form-control");
			  	x.setAttribute("name","answer"+i);
			  	modal.appendChild(x);
			}  
}
	  </script>
  </body>
</html>