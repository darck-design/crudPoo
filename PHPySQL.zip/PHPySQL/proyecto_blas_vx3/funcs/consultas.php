<?php
	function consultarPerfiles(){
		global $mysqli;
		
		$consulta = "SELECT id,username,fechaini,fechafin FROM usuarios WHERE tipo=2";
		$datos = $mysqli->query($consulta);
		
		if(!$datos || $mysqli->errno) die("error: no se pudo realizar la consulta ".$mysqli->errno);
		
		$resultados = array();
		while($fila = $datos->fetch_array()){
			$resultados[] = $fila;
		}
		$datos->free();
		return $resultados;
	}

	function consultarTests(){
		global $mysqli;
		
		$consulta = "SELECT id,titulo, (SELECT COUNT(*) FROM preguntas where preguntas.id_test = test.id) AS totalp FROM test";
		$datos = $mysqli->query($consulta);
		
		if(!$datos || $mysqli->errno) die("error: no se pudo realizar la consulta ".$mysqli->errno);
		
		$resultados = array();
		while($fila = $datos->fetch_array()){
			$resultados[] = $fila;
		}
		$datos->free();
		return $resultados;
	}

	function consultarTestsasignados($idu){
		global $mysqli;
		
		$consulta = "SELECT tasignados.id_test,titulo FROM test INNER JOIN tasignados ON test.id=tasignados.id_test and tasignados.id_usuario=$idu";
		$datos = $mysqli->query($consulta);
		
		if(!$datos || $mysqli->errno) die("error: no se pudo realizar la consulta ".$mysqli->errno);
		
		$resultados = array();
		while($fila = $datos->fetch_array()){
			$resultados[] = $fila;
		}
		$datos->free();
		return $resultados;
	}

	function consultarTestsNoasignados($idu){
		global $mysqli;
		
		$consulta = "SELECT titulo FROM test WHERE test.id NOT IN (SELECT DISTINCT tasignados.id_test FROM tasignados where tasignados.id_usuario = $idu)";
		$datos = $mysqli->query($consulta);
		
		if(!$datos || $mysqli->errno) die("error: no se pudo realizar la consulta ".$mysqli->errno);
		
		$resultados = array();
		while($fila = $datos->fetch_array()){
			$resultados[] = $fila;
		}
		$datos->free();
		return $resultados;
	}