<?php
	
	$msgOKRegistro= "<link rel='stylesheet' href='css/bootstrap.min.css' ><link rel='stylesheet' href='css/bootstrap-theme.min.css' >
				<script src='js/bootstrap.min.js' ></script>
				<div class='container'><div style='margin-top:50px' class='mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2'
				<div class='panel panel-info'><div class='panel-body' ><center><img src='img/ok.png'><br><h2>Registro Exitoso</h2>
				<a href='login.php'>Continuar</a></center></div></div></div></div>";

	
?>	