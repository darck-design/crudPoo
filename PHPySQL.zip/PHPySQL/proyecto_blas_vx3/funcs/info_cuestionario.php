<?php
require 'conexion.php';
require 'funcs.php';
session_start();

	if(isset($_SESSION['admin_logueado'])){
		
		if(isset($_POST['agregar'])){
			$titulo = limpiarCadena($mysqli->real_escape_string($_REQUEST['titulo_c']));
			$resultado = setTitulo($titulo);
			header("Location: ../cuenta_administrador.php");
			
		}else if(isset($_POST['agregar_preg'])){
			
			$pregunta = limpiarCadena($mysqli->real_escape_string($_REQUEST['preguntas_c']));
			
			$respuestaOrig = limpiarCadena($mysqli->real_escape_string($_REQUEST['respuesta_orig']));
			
			$respuestaAl1 = limpiarCadena($mysqli->real_escape_string($_REQUEST['respuesta_alea1']));
			
			$respuestaAl2 = limpiarCadena($mysqli->real_escape_string($_REQUEST['respuestaalea2']));
			
			$elementosResp = array();
			
			$valPreg = limpiarCadena($mysqli->real_escape_string($_REQUEST['id_val']));
			
			
			for($i=0;$i<$valPreg;$i=$i+1){
				
				if($_REQUEST['answer'.$i]!=NULL){
					$elementosResp[$i] = limpiarCadena($mysqli->real_escape_string($_REQUEST['answer'.$i]));
				}
					
			}
			
			$id_test = $_REQUEST['id_Titulo'];	
			
		
			
			$resultadoP = setQuestion($id_test,$pregunta,$elementosResp,$respuestaOrig,$respuestaAl1,$respuestaAl2,$valPreg);
			
			if($resultadoP){
				header("Location: ../cuenta_administrador.php");
			}else echo "hay Errores man";
			
			
		}
		else if(isset($_POST['asignar'])){
			
			$id_user = $_REQUEST['id_User'];
			$id_test = $_REQUEST['id_Titulo'];	
			
			$resultadoP = setTestUser($id_test,$id_user);
			
			header("Location: ../cuenta_administrador.php");
		}	
	}else{
		header("Location: logout.php");
	}
?>