<?php
	function resultBlock($errors){
		if(count($errors) > 0)
		{
			echo "<div id='error' class='alert alert-danger' role='alert'>
			<a href='#' onclick=\"document.getElementById('error').style.display='none';\">[X]</a>
			<ul>";
			foreach($errors as $error)
			{
				echo "<li>".$error."</li>";
			}
			echo "</ul>";
			echo "</div>";
		}
	}

	function isNull($nControl, $nombre, $pass, $pass_con, $email){
		if(strlen(trim($nControl)) < 1 || strlen(trim($nombre)) < 1 || strlen(trim($pass)) < 1 || strlen(trim($pass_con)) < 1 || strlen(trim($email)) < 1)
			return true;
		else 
			return false;
		
	}

	function isEmail($email){
		if (filter_var($email, FILTER_VALIDATE_EMAIL))
			return true;
		else 
			return false;
	}

	function validaPassword($var1, $var2){
		if (strcmp($var1, $var2) !== 0)
			return false;
		else
			return true;
	}

	function usuarioExiste($usuario){
		global $mysqli;
		
		$stmt = $mysqli->prepare("SELECT username FROM usuarios WHERE username = ? LIMIT 1");
		$stmt->bind_param("s", $usuario);
		$stmt->execute();
		$stmt->store_result();
		$num = $stmt->num_rows;
		$stmt->close();
		
		if ($num > 0){
			return true;
		} else
			return false;
	}

	function emailExiste($email){
		global $mysqli;
		
		$stmt = $mysqli->prepare("SELECT NControl FROM egresados WHERE Correo = ? LIMIT 1");
		$stmt->bind_param("s", $email);
		$stmt->execute();
		$stmt->store_result();
		$num = $stmt->num_rows;
		$stmt->close();
		
		if ($num > 0)
			return true;
		else 
			return false;
	}

	function hashPassword($password){
		$hash = password_hash($password, PASSWORD_DEFAULT);
		return $hash;
	}

	function registraUsuario($nu, $pass_hash,$activo, $tipo, $fechai, $fechaf){
		global $mysqli;
		$cActivo=2;
		
		$stmt = $mysqli->prepare("INSERT INTO usuarios (username, password, activo, tipo, fechaini, fechafin) VALUES('$nu','$pass_hash', $activo, $tipo, '$fechai', '$fechaf')");
		//$stmt->bind_param('ssiidd', $nu, $pass_hash, $activo, $tipo, $fechai, $fechaf);
		if ($stmt->execute())
			return $mysqli->insert_id;
		 else
			return 0;
	}
	
	function limpiarCadena($cad){
		$cadL = str_replace("<","",$cad);
		$cadL = str_replace(">","",$cadL);
		$cadL = str_replace("$","",$cadL);
		$cadL = str_replace("[","",$cadL);
		$cadL = str_replace("]","",$cadL);
		$cadL = str_replace("#","",$cadL);
		$cadL = str_replace(";","",$cadL);
		return $cadL;
	}

	function isNullLogin($usuario, $password){
		if(strlen(trim($usuario)) < 1 || strlen(trim($password)) < 1)
			return true;
		else
			return false;
	}

	function login($usuario, $password, $tipou){
		global $mysqli;

		if($tipou=='on')
			$tipous = 1;
		else
			$tipous = 2;

		$stmt = $mysqli->prepare("SELECT id, username, password FROM usuarios WHERE tipo = $tipous  AND username='$usuario'LIMIT 1");
		
		$stmt->execute();
		$stmt->store_result();
		$rows = $stmt->num_rows;
		
		if($rows > 0) {
			$stmt->bind_result($idus, $usuario, $passwd);
			$stmt->fetch();
			//$stmt->bind_param("ss", $usuario, $usuario);
			$validaPassw = password_verify($password, $passwd);
			
			if($validaPassw){
				$_SESSION['id_usuario'] = $idus;
				$_SESSION['usuario'] = $usuario;
				$_SESSION['tipo_usuario'] = $tipou;
				$_SESSION['logueado'] = true;
				$_SESSION['existeTests'] = 0;
				if($tipous==1){
					$_SESSION['admin_logueado'] = true;
					header("location: cuenta_administrador.php");
				}else{
					$query = " select count(*) from usuarios where id=? and fechafin <= curdate()";
			        $stmt = $mysqli->prepare($query);
			        $stmt->bind_param('i',$idus);
			        $stmt->execute();
			        $stmt->bind_result($total);
			        $stmt->fetch();
			        $stmt->close();
		            if($total>0){
		              $errors = "Su tiempo ha expirado por favor pongase en contacto con el Administrador";
		            }else{
		             header("location: cuenta_cliente.php"); 
		            }
				}
			} else
				$errors = "La contraseña es incorrecta";
		}else 
			$errors = "El usuario no existe";
		return $errors;
	}
	
	function setTitulo($titulo){
		global $mysqli;
		$stmt = $mysqli->prepare("INSERT INTO test(titulo) VALUES(?)");
		$stmt->bind_param('s',$titulo);
		if($stmt->execute()){
			$stmt->close();
			return $mysqli->insert_id;
		}else{
			return 0;
		}
	}

	function getTitulos(){
		global $mysqli;
		$query = "SELECT * FROM test";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$result = $stmt->get_result();
		$stmt->close();
		return $result;
	}

	function existeTest($titulo){
		global $mysqli;
		/*$stmt = $mysqli->prepare("SELECT id FROM test WHERE titulo = '$titulo'");
		$stmt->execute();
		$stmt->store_result();
		$rows = $stmt->num_rows;
		
		if($rows > 0)
			return 1;
		else
			return 0;*/

		$sql = "SELECT id FROM test WHERE titulo = '$titulo'";
		$result = $mysqli->query($sql);
		$row = $result->fetch_assoc();

		if($row > 0)
			return $row['id'];
		else
			return 0;
	}

	function getUsuarios(){
		global $mysqli;
		$query = "SELECT * FROM usuarios WHERE tipo=2";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$result = $stmt->get_result();
		$stmt->close();
		return $result;
	}

	function setTestUser($id_test,$id_user){
		global $mysqli;
		$query = "SELECT id_usuario FROM tasignados WHERE tasignados.id_usuario = $id_user AND tasignados.id_test = $id_test";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$result = $stmt->get_result();
		
		if(mysqli_num_rows($result) == 0){
			$stmt = $mysqli->prepare("INSERT INTO tasignados(id_usuario,id_test) VALUES (?,?)");
			$stmt->bind_param('ii',$id_user,$id_test);
			if($stmt->execute()){
				$stmt->close();
				return 1;
			}else{
				return -1;
			}
		}else
			return 0;
		
	}

	function setQuestion($id_test,$pregunta,$respuesta,$respuestaOrig,$respuestaAl1,$respuestaAl2,$cantidad){
			global $mysqli;
		$stmt = $mysqli->prepare("INSERT INTO preguntas(id_test,pregunta) VALUES(?,?)");
		$stmt->bind_param('is',$id_test,$pregunta);
		
		if($stmt->execute()){
			$valID = $mysqli->insert_id;
			$j=0; 
			
			$tipo_respuesta = 1;
			$stmt = $mysqli->prepare("INSERT INTO respuestas(id_test,id_pregunta,respuesta,tipo_respuesta) VALUES(?,?,?,?)");
			$stmt->bind_param('iisi',$id_test,$valID,$respuestaOrig,$tipo_respuesta);
			$stmt->execute();
			$stmt->close();
			
			$tipo_respuesta = 0; 	
			
			$stmt = $mysqli->prepare("INSERT INTO respuestas(id_test,id_pregunta,respuesta,tipo_respuesta) VALUES(?,?,?,?)");
			$stmt->bind_param('iisi',$id_test,$valID,$respuestaAl1,$tipo_respuesta);
			$stmt->execute();
			$stmt->close();
		
			$stmt = $mysqli->prepare("INSERT INTO respuestas(id_test,id_pregunta,respuesta,tipo_respuesta) VALUES(?,?,?,?)");
			$stmt->bind_param('iisi',$id_test,$valID,$respuestaAl2,$tipo_respuesta);
			$stmt->execute();
			$stmt->close();
			
			for($j=0;$j<$cantidad;$j=$j+1){
				if($respuesta[$j]!=NULL){
					$stmt = $mysqli->prepare("INSERT INTO respuestas(id_test,id_pregunta,respuesta,tipo_respuesta) VALUES(?,?,?,?)");
					$stmt->bind_param('iisi',$id_test,$valID,$respuesta[$j],$tipo_respuesta);
					$stmt->execute();
					$stmt->close();
				}
			}
			return 1;
		}else{
			return 0;
		}
	}

	function setPregunta($id_test,$pregunta){
		global $mysqli;
		$stmt = $mysqli->prepare("INSERT INTO preguntas(id_test,pregunta) VALUES(?,?)");
		$stmt->bind_param('is',$id_test,$pregunta);
		if($stmt->execute()){
			$stmt->close();
			return $mysqli->insert_id;
		}else{
			return 0;
		}
	}

	function setRespuesta($id_test,$id_pregunta,$respuesta,$tipo){
		global $mysqli;
		$stmt = $mysqli->prepare("INSERT INTO respuestas(id_test,id_pregunta,respuesta,tipo_respuesta) VALUES(?,?,?,?)");
		$stmt->bind_param('iisi',$id_test,$id_pregunta,$respuesta,$tipo);
		if($stmt->execute()){
			$stmt->close();
			return $mysqli->insert_id;
		}else{
			return 0;
		}
	}

	function getListaDeIds($id_test){
		global $mysqli;
			$result = array();
				$query = "SELECT id FROM preguntas WHERE id_test=$id_test";
				$stmt = $mysqli->prepare($query);
				$stmt ->execute();
				
			$stmt -> bind_result($valId);
		while($stmt->fetch()){
			$result[] = $valId;
		}
				$stmt->close();
		
			return $result;
	}

	function getPregunta($contador){
		global $mysqli;
				$query = "SELECT pregunta FROM preguntas WHERE id = $contador";
				$stmt = $mysqli->prepare($query);
				
				$stmt ->execute();
				$result = $stmt->get_result();
				$stmt->close();
			
			if($result!=NULL){
				return $result;	
			}else{
				return $result=0;
			}
	}

	function getRespuestas($Depregunta){
		global $mysqli;
		$result = array();
		$query = "SELECT id,respuesta FROM respuestas WHERE id_pregunta = $Depregunta order by rand()";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$result = $stmt->get_result();

		while($stmt->fetch()){
			$result[] = $valId;
		}
			$stmt->close();
		return $result;
	}

	function getRespuestaCorrecta($id_preg){
		global $mysqli;
		$query = "SELECT id FROM respuestas WHERE id_pregunta=$id_preg AND tipo_respuesta=1";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$resultado = $stmt->get_result();
		$row_a = $resultado->fetch_row();
		$result = $row_a[0];
		$stmt->close();
		return $result;
	}

	function getTotalT($id_test){
		global $mysqli;
		$query = "select count(*) from preguntas where id_test=$id_test";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$resultado = $stmt->get_result();
		$row_a = $resultado->fetch_row();
		$result = $row_a[0];
		$stmt->close();
		return $result;
	}

	function getAllQuestions($id_test){
		global $mysqli;
		$query = "SELECT id,pregunta FROM preguntas where id_test = ?";
		$stmt = $mysqli->prepare($query);
		$stmt->bind_param('i',$id_test);
		$stmt ->execute();
		$result = $stmt->get_result();
		$stmt->close();			
		return $result;	
	}

	function getRespuestasEditar($Depregunta){
		global $mysqli;
		$result = array();
		$query = "SELECT respuesta,tipo_respuesta,id FROM respuestas WHERE id_pregunta = $Depregunta";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$result = $stmt->get_result();

		while($stmt->fetch()){
			$result[] = $valId;
		}
			$stmt->close();
		return $result;
		}
	//update question
	function setUpdateQ($texto,$id){
		global $mysqli;
		$query = "UPDATE preguntas set pregunta = ? where id = ? ";
		$stmt= $mysqli->prepare($query);
		$stmt->bind_param('si',$texto,$id);
		if($stmt->execute()){
			return 1;
		}else{
			return 0;
		}
	}
	//update answer
	function setUpdateA($texto,$id_pregunta,$id){
		global $mysqli;
		$query = "UPDATE respuestas set respuesta = ? where id_pregunta = ?  and id= ? ";
		$stmt= $mysqli->prepare($query);
		$stmt->bind_param('sii',$texto,$id_pregunta,$id);
		if($stmt->execute()){
			return 1;
		}else{
			return 0;
		}
	}

	function getATest($id){
		global $mysqli;
		$query = "SELECT titulo FROM test where id = ?";
		$stmt = $mysqli->prepare($query);
		$stmt->bind_param('i',$id);
		$stmt ->execute();
		$result = $stmt->get_result();
		$row_a = $result->fetch_row();
		$result = $row_a[0];
		$stmt->close();
		return $result;
	}

	function getCurrentDay($id_usuario){
	    global $mysqli;
	    $query = " select count(*) from usuarios where id= ? and fechafin = curdate()+2";
	    $stmt = $mysqli->prepare($query);
		$stmt->bind_param('i',$id_usuario);
		$stmt ->execute();
	    $stmt->bind_result($cntidad);
	    $stmt->fetch();
	    $stmt->close();
	    if($cntidad>0){
	      $_SESSION['avisoTime'] = "Tiene dos días restantes para que finalize su periodo. Por favor contacte al administrador para adquirir una cuenta nueva";
	      return 1;
	    }else
	      return 0;
	}

	function getUsuariosFin(){
	  	global $mysqli;
		$query = " select username from usuarios where fechafin <= curdate()";
		$stmt = $mysqli->prepare($query);
		$stmt ->execute();
		$result = $stmt->get_result();
		$stmt->close();			
		return $result;	
	}

?>	